<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Presensi;
use App\Models\PresensiDetail;

class PresensiController extends Controller
{
    public function get()
    {
        $presensi = Presensi::with('presensi_detail', 'kegiatan')->get();

        if ($presensi) {
            return response()->json([
                'statusCode' => 200,
                'status' => true,
                'data' => $presensi,
                'message' => 'data presensi sukses'
            ], 200);
        } else {
            return response()->json([
                'statusCode' => 500,
                'status' => false,
                'data' => null,
                'message' => 'data presensi gagal'
            ], 500);
        }
    }

    public function getOpen()
    {
        $presensi = Presensi::where('is_open', 1)->first();

        if ($presensi) {
            return response()->json([
                'statusCode' => 200,
                'status' => true,
                'data' => $presensi,
                'message' => 'data presensi sukses'
            ], 200);
        } else {
            return response()->json([
                'statusCode' => 500,
                'status' => false,
                'data' => null,
                'message' => 'data presensi tidak ada'
            ], 500);
        }
    }

    public function detail(Request $req)
    {
        $presensi = Presensi::with('presensi_detail', 'kegiatan')->where('id', $req->query('presensi'))->first();

        if ($presensi) {
            return response()->json([
                'statusCode' => 200,
                'status' => true,
                'data' => $presensi,
                'message' => 'data presensi sukses'
            ], 200);
        } else {
            return response()->json([
                'statusCode' => 500,
                'status' => false,
                'data' => null,
                'message' => 'data presensi gagal'
            ], 500);
        }
    }

    public function create(Request $req)
    {
        $presensi = new Presensi();
        $presensi->kegiatan_id = $req->kegiatan;
        $presensi->keterangan = $req->keterangan;
        $presensi->tgl_open = $req->tgl_open;
        $presensi->tgl_close = $req->tgl_close;
        $presensi->save();

        if ($presensi) {
            return response()->json([
                'statusCode' => 200,
                'status' => true,
                'data' => $presensi,
                'message' => 'data presensi sukses'
            ], 200);
        } else {
            return response()->json([
                'statusCode' => 500,
                'status' => false,
                'data' => null,
                'message' => 'data presensi gagal'
            ], 500);
        }
    }

    public function fillPresensi(Request $req)
    {
        $presensi = Presensi::where('is_open', 1)->first();

        if ($presensi) {
            $presensiDetail = new PresensiDetail();
            $presensiDetail->presensi_id = $presensi->id;
            $presensiDetail->nomor_cacah_krama_mipil = $req->nomor_cacah_krama_mipil;
            $presensiDetail->uid_kartu = $req->uid_kartu;
            $presensiDetail->save();

            if ($presensiDetail) {
                return response()->json([
                    'statusCode' => 200,
                    'status' => true,
                    'data' => $presensiDetail,
                    'message' => 'data presensi sukses'
                ], 200);
            } else {
                return response()->json([
                    'statusCode' => 500,
                    'status' => false,
                    'data' => null,
                    'message' => 'data presensi gagal'
                ], 500);
            }
        } else {
            return response()->json([
                'statusCode' => 500,
                'status' => false,
                'data' => null,
                'message' => 'no presensi open'
            ], 500);
        }
    }

    public function openPresensi(Request $req)
    {
        $presensi = Presensi::where('is_open', 1)->first();

        if($presensi) {
            return response()->json([
                'statusCode' => 500,
                'status' => false,
                'data' => null,
                'message' => 'presensi already open'
            ], 200);
        } else {
            $presensi = Presensi::where('id', $req->query('presensi'))->first();
            $presensi->is_open = 1;
            $presensi->save();

            if ($presensi) {
                return response()->json([
                    'statusCode' => 200,
                    'status' => true,
                    'data' => $presensi,
                    'message' => 'data presensi sukses'
                ], 200);
            } else {
                return response()->json([
                    'statusCode' => 500,
                    'status' => false,
                    'data' => null,
                    'message' => 'data presensi gagal'
                ], 500);
            }
        }
    }
}
